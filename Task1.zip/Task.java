class Flow {
    public void methodA() {
        // Print part of the phrase
        System.out.print("J");
    }

    public void methodB() {
        System.out.print("a");
    }

    public void methodC() {
        System.out.print("v");
    }

    public void methodD() {
        System.out.print("a");
    }

    public void methodE() {
        System.out.print(" ");
    }

    public void methodF() {
        System.out.print("e");
    }

    public void methodG() {
        System.out.print("r");
    }

    public void methodH() {
        System.out.print(" ");
    }

    public void methodI() {
        System.out.print("s");
    }

    public void methodJ() {
        System.out.print("j");
    }

    public void methodK() {
        System.out.print("o");
    }

    public void methodL() {
        System.out.print("v");
    }

    public void methodM() {
        System.out.print("t");
    }
}
