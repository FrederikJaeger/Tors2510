public class Main {
    public static void main(String[] args) {
        Flow flow = new Flow();
        flow.methodA();
        flow.methodB();
        flow.methodC();
        flow.methodD();
        flow.methodE();
        flow.methodF();
        flow.methodG();
        flow.methodH();
        flow.methodI();
        flow.methodJ();
        flow.methodK();
        flow.methodL();
        flow.methodM();
    }
}
