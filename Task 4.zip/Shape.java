public interface Shape {
    double getArea();
}
